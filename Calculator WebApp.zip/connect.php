<?php
  $dbServername = 'localhost';
  $dbUsername = '390674';
  $dbPassword = 'RiYtYiZU6R5Lh0Ns';
  $dbName = '390674';

  $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
